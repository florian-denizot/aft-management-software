DROP TABLE IF EXISTS `#__aftms_courses`;
DROP TABLE IF EXISTS `#__aftms_course_groups`;
DROP TABLE IF EXISTS `#__aftms_classrooms`;
DROP TABLE IF EXISTS `#__aftms_campuses`;