<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_aftms
 */

defined('_JEXEC') or die;

/**
 * Course import administration controller class.
 * 
 * @package     Joomla.Administrator
 * @subpackage  com_aftms
 */
class AFTMSControllerCourseImport extends JControllerForm
{
  
}
